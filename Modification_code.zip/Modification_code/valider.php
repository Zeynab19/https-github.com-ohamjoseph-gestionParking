<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="SeconnecterP.php" method="POST">
                
                <div class="liens">
                        <button type="button" class="autres_pages"> <a href="info_ent_client.php">Les informations du client entrant dans le parking</a></button><br><br>
                        
                        <button type="button" class="autres_pages"><a href="info_sort_client.php">Les informations du client sortant du parking</a></button><br><br>
                          
                </div>       
            </form>

</body>   
<html>