<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php
require_once('Controller.php');
include("Model.php");
if(isset($_POST['champ']))
{ 
$champ=$_POST['champ'];
$valeur=$_POST['valeur'];

$rech = new rechercherClient();
$rech->recherche($champ,$valeur);
}
?>

</body>
</html>