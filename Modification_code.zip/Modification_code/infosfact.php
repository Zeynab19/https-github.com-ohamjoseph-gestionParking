<!DOCTYPE html>
<html lang="en">
<head>
    <meta charscet="UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="CSS\bootstrap\css\bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style2.css" media="screen" type="text/css" />
    <title>Document</title>
</head>
<body style="margin-left: 25%">
<?php
require_once('Controller.php');
include("Model.php");




if(isset($_POST['montant']))
{
   
    $code_identification = $_POST['code_identification'];
    
    $montant = $_POST['montant'];
    

    $fact = new Validationcontroller();
    $fact->save_facture($code_identification,$montant);

}

?>

<center><div class="card bg-light mb-3" style="max-width: 40rem;">

<center>  <div class="card-header"><h1> Validation de paiement </h1></div> </center>

<h2>Veuillez remplir les champs suivants:</h2>
<form  action="" method="post">
 
<div class="card-body">


<label for="code_identification" class="card-title" required/> Code </label > :
 <input type ="text" name="code_identification" required/><br><br>

 <label for="montant" class="card-title"> Montant </label > :
    <select name="montant">
	 <option>50 francs</option>
	 <option>100 francs</option>
	 <option>200 francs </option>
</select><br><br>
 
</div>
<a href="infostact.php"> <button type="submit" class="btn btn-success">Ajouter</button> </a>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<a href="Administrateur.php"> <button  type="button" style="color: white"  class="btn btn-danger">Retour</button></a><br><br>


</form>
</div>
</div>

</center>

<center>
<form style="color: black">
	<fieldset style="width: 40%" >
		<legend><h1 style="color:blue">Liste des clients payé </h1></legend>
<?php
 
 $liste = new liste_validationController();

 $liste->liste();

?></center>
</fieldset>
</form>

</body>
</html>