<!DOCTYPE html>
<html lang="en">
<head>
    <meta charscet="UTF-8">
    <!-- import des fichiers css et bootstrap -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="CSS\bootstrap\css\bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style2.css" media="screen" type="text/css" />
    <title>Document</title>
</head>
<body>
<?php
//import des fichiers controller et model
require_once('Controller.php');
include("Model.php");

//La recupération des données dans le formulaire
if(isset($_POST['nom']))
{
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $tel= $_POST['tel'];
    $engin = $_POST['engin'];
    $code_identification= $_POST['code_identification'];
    //Création d'une instance de classe 
    $erg = new AdministrateurController();
    $erg->save_client($nom,$prenom,$tel,$engin,$code_identification);

}

?>

<center><div class="card bg-light mb-3" style="max-width: 40rem;">

<center>  <div class="card-header"><h1> Enregistrer un client </h1></div> </center>

<h2>Veuillez remplir les champs suivants:</h2>
<form  action="" method="post">
 
<div class="card-body">
    
<label for="nom" class="card-title" required/> Nom client </label > :
 <input type ="text" name="nom" required/><br><br>
 <label for="prenom" class="card-title"> Prénom </label > :
 <input type ="text" name="prenom" required/><br><br>
 <label for="tel" class="card-title"> Téléphone </label > :
 <input type ="text" name="tel" required/><br><br>
 <label for="engin" class="card-title"> Catégorie d'engin </label > :
 <select name="engin">
	 <option>Velo</option>
	 <option>Moto</option>
	 <option>Voiture </option>
</select><br><br>
 <label for="code_identification" class="card-title"> Code identification </label > :
 <input type ="text" name="code_identification" required/><br><br>
</div>

<button type="submit"   style="color: white"  class="btn btn-success">enregistrer</button>

&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<a href="Administrateur.php"> <button  type="button" style="color: white"  class="btn btn-danger">Retour</button></a><br><br>
</form>
</div>
</div>
<center>
<script src="CSS\bootstrap\js\bootstrap.bundle.min.js"></script>


</body>
</html>