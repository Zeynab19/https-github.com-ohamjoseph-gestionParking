<!DOCTYPE html>
<html>
<head>
	<title></title>
  <link rel="stylesheet" href="style2.css" media="screen" type="text/css" />
  <link href="CSS\bootstrap\css\bootstrap.min.css" rel="stylesheet">
</head>
<body style="margin-left: 10%">
<?php
require_once('Controller.php');
include("Model.php");

if(isset($_POST['NumPlace']))
{
    
    $numplace = $_POST['NumPlace'];
    $etat= $_POST['etat'];
    $engin = $_POST['engin'];
    $code_identification= $_POST['code_identification'];

    $erg = new modificationController();
    $erg->modif($numplace,$etat,$code_identification,$engin);

}

?>
<center><div class="card bg-light mb-3" style="max-width: 40rem;">

<center>  <div class="card-header"><h1> L'entré d'un client dans le parking</h1></div> </center>
 <form action="" method="post">
  
  <div class="card-body"> 
 <legend><h1 style="color:blue"></h1></legend> 
 
 
 <label for="NumPlace" class="card-title" required> Le numero de place  </label > :
 <input type ="text" name="NumPlace" required/> <br><br>
 <label for="etat" class="card-title"> Etat de place</label > :
  <select name="etat">
	 <option>Libre</option>
	 <option>Occupé </option>
</select><br><br>

 <label for="code_identification" class="card-title"> Code d'identicafication </label > :
 <input type ="text" name="code_identification" required/><br><br>
 <label for="engin" class="card-title"> Catégorie d'engin </label > :
  <select name="engin">
	 <option>Vélo</option>
	 <option>Moto</option>
	 <option>Voiture </option>
</select><br><br>
</div>
<button type="submit" style="color: white"  class="btn btn-success" name="modifier">Modifier</button> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<a href="Administrateur.php"> <button  type="button" style="color: white"  class="btn btn-danger">Retour</button></a><br><br>
</form>
</div>
</div>
</center>
<script src="CSS\bootstrap\js\bootstrap.bundle.min.js"></script>
</body>
</html>